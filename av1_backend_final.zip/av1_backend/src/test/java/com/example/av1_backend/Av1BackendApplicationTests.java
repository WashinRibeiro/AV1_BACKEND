package com.example.av1_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Av1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
