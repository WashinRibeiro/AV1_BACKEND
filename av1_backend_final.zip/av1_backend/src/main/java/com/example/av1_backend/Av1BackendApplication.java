package com.example.av1_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Av1BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Av1BackendApplication.class, args);
	}

}
